self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ab68f5a09b4ee68bcc792fada22396c6",
    "url": "/hotfix/index.html"
  },
  {
    "revision": "7985fe00b8ab9201eec1",
    "url": "/hotfix/static/css/main.a1107254.chunk.css"
  },
  {
    "revision": "3653dceec2bb1395e4ce",
    "url": "/hotfix/static/js/2.84911def.chunk.js"
  },
  {
    "revision": "41b66b6fd6eecba581340794bb1831be",
    "url": "/hotfix/static/js/2.84911def.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7985fe00b8ab9201eec1",
    "url": "/hotfix/static/js/main.641ec301.chunk.js"
  },
  {
    "revision": "a5513f98fd1945ffd5c8",
    "url": "/hotfix/static/js/runtime-main.5928ce89.js"
  },
  {
    "revision": "dfc54362fc2b0f7b99a4038b87dd9e64",
    "url": "/hotfix/static/media/1.dfc54362.png"
  },
  {
    "revision": "2048975925bd8553d8aaa5e1d9d1ffb1",
    "url": "/hotfix/static/media/2.20489759.png"
  },
  {
    "revision": "dbf82c38432d45de3c1c99f13c8b5fee",
    "url": "/hotfix/static/media/3.dbf82c38.png"
  },
  {
    "revision": "e671d53961f44185ee61256a0e6f13a5",
    "url": "/hotfix/static/media/4.e671d539.png"
  },
  {
    "revision": "35bcd06768ffafae4a5721b8f0c4fd8f",
    "url": "/hotfix/static/media/burger.35bcd067.png"
  },
  {
    "revision": "06277842ccc3f7c2a37085189dacdcbc",
    "url": "/hotfix/static/media/check-symbol.06277842.svg"
  },
  {
    "revision": "751f84c25a8d1ff159f499cbb9aa5bb7",
    "url": "/hotfix/static/media/edit.751f84c2.svg"
  },
  {
    "revision": "4fd2ba47b4f59d0a4382a8d81aae85d6",
    "url": "/hotfix/static/media/kfc.4fd2ba47.png"
  },
  {
    "revision": "60464810e8cfcde7a20fc19284c38a0e",
    "url": "/hotfix/static/media/mcdac.60464810.png"
  },
  {
    "revision": "1198ed41690cc0974aa8baa0e95ebd1b",
    "url": "/hotfix/static/media/refresh-button.1198ed41.svg"
  },
  {
    "revision": "4eb05fdd9f3d81f2f81cac5847e25cc9",
    "url": "/hotfix/static/media/sub.4eb05fdd.png"
  }
]);